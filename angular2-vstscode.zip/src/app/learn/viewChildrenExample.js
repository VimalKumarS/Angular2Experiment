"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var MyCustomDirective = (function () {
    function MyCustomDirective(_renderer, _el) {
        this._renderer = _renderer;
        this._el = _el;
    }
    MyCustomDirective.prototype.changeCssClass = function (className, isAdd) {
        this._renderer.setElementClass(this._el.nativeElement, className, isAdd);
    };
    MyCustomDirective = __decorate([
        core_1.Directive({
            selector: '[my-custom-directive]',
            exportAs: 'customdirective'
        }), 
        __metadata('design:paramtypes', [core_1.Renderer, core_1.ElementRef])
    ], MyCustomDirective);
    return MyCustomDirective;
}());
exports.MyCustomDirective = MyCustomDirective;
var ViewAppComponent = (function () {
    function ViewAppComponent() {
    }
    ViewAppComponent.prototype.changeCssClassForFirst = function () {
        this.removeClassFromAll();
        this.first.changeCssClass('red', true);
    };
    ViewAppComponent.prototype.changeCssClassForSecond = function () {
        this.removeClassFromAll();
        this.second.changeCssClass('red', true);
    };
    ViewAppComponent.prototype.changeCssClassForAll = function () {
        this.removeClassFromAll();
        this.allMyCustomDirectives.forEach(function (d) { return d.changeCssClass('red', true); });
    };
    ViewAppComponent.prototype.removeClassFromAll = function () {
        this.allMyCustomDirectives.forEach(function (d) { return d.changeCssClass('red', false); });
    };
    __decorate([
        core_1.ViewChild('cdire'), 
        __metadata('design:type', Object)
    ], ViewAppComponent.prototype, "second", void 0);
    __decorate([
        core_1.ViewChild(MyCustomDirective), 
        __metadata('design:type', Object)
    ], ViewAppComponent.prototype, "first", void 0);
    __decorate([
        core_1.ViewChildren(MyCustomDirective), 
        __metadata('design:type', Object)
    ], ViewAppComponent.prototype, "allMyCustomDirectives", void 0);
    ViewAppComponent = __decorate([
        core_1.Component({
            selector: 'my-app',
            styles: ['.red{background-color:#eee;color:red}'],
            template: "\n\t\n\t <div class=\"row\">\n\t  <button (click)=\"changeCssClassForAll()\">Change all</button>\n\t  <button (click)=\"changeCssClassForFirst()\">Change first</button>\n\t  <button (click)=\"changeCssClassForSecond()\">Change Second</button>\n\t </div>\n\t<div my-custom-directive>First custom directive</div>\n\t<div #cdire=customdirective my-custom-directive>Second custom directive</div>\n\t<div my-custom-directive>Third custom directive</div>\n\t"
        }), 
        __metadata('design:paramtypes', [])
    ], ViewAppComponent);
    return ViewAppComponent;
}());
exports.ViewAppComponent = ViewAppComponent;
//# sourceMappingURL=viewChildrenExample.js.map