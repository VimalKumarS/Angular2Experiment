"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var TodoList = (function () {
    function TodoList() {
        this.todos = [];
    }
    TodoList.prototype.add = function (todo) {
        this.todos.push(todo);
    };
    TodoList.prototype.remove = function (todo) {
        this.todos.splice(this.todos.indexOf(todo), 1);
    };
    TodoList.prototype.set = function (todo, index) {
        this.todos[index] = todo;
    };
    TodoList.prototype.get = function (index) {
        return this.todos[index];
    };
    TodoList.prototype.getAll = function () {
        return this.todos;
    };
    return TodoList;
}());
exports.TodoList = TodoList;
var TodoComponent = (function () {
    function TodoComponent() {
        this.onCompletionChange = new core_1.EventEmitter();
    }
    TodoComponent.prototype.completionChanged = function (todo) {
        this.onCompletionChange.emit(todo);
    };
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], TodoComponent.prototype, "onCompletionChange", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Object)
    ], TodoComponent.prototype, "todo", void 0);
    TodoComponent = __decorate([
        core_1.Component({
            selector: 'todo-item',
            styles: [
                ".completed {\n      text-decoration: line-through;\n    }"
            ],
            template: "\n    <div [class.completed]=\"todo.completed\">\n      <input type=\"checkbox\"\n        [(ngModel)]=\"todo.completed\"\n        (change)=\"completionChanged(todo)\">\n      {{todo.title}}\n    </div>\n  "
        }), 
        __metadata('design:paramtypes', [])
    ], TodoComponent);
    return TodoComponent;
}());
exports.TodoComponent = TodoComponent;
var TodoInputComponent = (function () {
    function TodoInputComponent() {
        this.onTodo = new core_1.EventEmitter();
    }
    TodoInputComponent.prototype.addTodo = function () {
        this.onTodo.emit({
            title: this.title,
            completed: false
        });
        this.title = '';
    };
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], TodoInputComponent.prototype, "onTodo", void 0);
    TodoInputComponent = __decorate([
        core_1.Component({
            selector: 'todo-input',
            template: "\n    <input type=\"text\" [(ngModel)]=\"title\">\n    <button (click)=\"addTodo()\">Add</button>\n  "
        }), 
        __metadata('design:paramtypes', [])
    ], TodoInputComponent);
    return TodoInputComponent;
}());
exports.TodoInputComponent = TodoInputComponent;
var FooterComponent = (function () {
    function FooterComponent(todos) {
        this.todos = todos;
    }
    FooterComponent = __decorate([
        core_1.Component({
            selector: 'app-footer',
            template: '<ng-content></ng-content>'
        }), 
        __metadata('design:paramtypes', [TodoList])
    ], FooterComponent);
    return FooterComponent;
}());
exports.FooterComponent = FooterComponent;
var TodoAppComponent = (function () {
    function TodoAppComponent(todos) {
        this.todos = todos;
    }
    TodoAppComponent.prototype.addTodo = function (todo) {
        this.todos.add(todo);
    };
    TodoAppComponent.prototype.ngAfterViewInit = function () {
        // console.log(this.input);
    };
    __decorate([
        core_1.ViewChild(TodoInputComponent), 
        __metadata('design:type', TodoInputComponent)
    ], TodoAppComponent.prototype, "input", void 0);
    TodoAppComponent = __decorate([
        core_1.Component({
            selector: 'todo-app',
            viewProviders: [TodoList],
            template: "\n    <section>\n      Add todo:\n      <todo-input (onTodo)=\"addTodo($event)\"></todo-input>\n    </section>\n    <section>\n      <h4 *ngIf=\"todos.getAll().length\">Todo list</h4>\n      <todo-item *ngFor=\"let todo of todos.getAll()\" [todo]=\"todo\">\n      </todo-item>\n    </section>\n    <ng-content select=\"app-footer\"></ng-content>\n  "
        }), 
        __metadata('design:paramtypes', [TodoList])
    ], TodoAppComponent);
    return TodoAppComponent;
}());
exports.TodoAppComponent = TodoAppComponent;
var TodoAppMainComponent = (function () {
    function TodoAppMainComponent() {
    }
    TodoAppMainComponent = __decorate([
        core_1.Component({
            selector: 'demo-app',
            styles: [
                'todo-app { margin-top: 20px; margin-left: 20px; }'
            ],
            template: "\n    <content>\n      <todo-app>\n        <app-footer>\n          <small>Yet another todo app!</small>\n        </app-footer>\n      </todo-app>\n    </content>\n  "
        }), 
        __metadata('design:paramtypes', [])
    ], TodoAppMainComponent);
    return TodoAppMainComponent;
}());
exports.TodoAppMainComponent = TodoAppMainComponent;
//# sourceMappingURL=todo.js.map