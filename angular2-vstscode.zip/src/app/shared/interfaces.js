"use strict";
var PaginatedResult = (function () {
    function PaginatedResult() {
    }
    return PaginatedResult;
}());
exports.PaginatedResult = PaginatedResult;
//# sourceMappingURL=interfaces.js.map